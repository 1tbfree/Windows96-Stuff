// Create api reference
const w96 = parent.w96;

async function fsDemo() {
    const cnt = document.querySelector(".fsdemo>.files");
    const files = await w96.FS.readdir("C:/");

    files.forEach((v)=>{
        cnt.appendChild(new Text(v + " "));
    });
}