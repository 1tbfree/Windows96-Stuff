# Win96 SWFS Demo

A demonstration showing off the Service Worker Filesystem Redirect/Bridge as a hybrid, single window Iframe-based app.

## How to run
Double click `uiApp`.