const btn = document.querySelector("#btn");
btn.addEventListener('click', ()=> {
     const textEl = document.querySelector("#text");
     textEl.textContent = "This text has been updated.";
});